package br.com.ldroidg;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import com.jcraft.jsch.*;

public class MainActivity extends Activity {
    private EditText ip, port, packageUrl;
    private TextView status;
    private Uri keyUri;
    private Button keyButton, testButton, installButton;
    private static final int PICK_KEY = 41;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setBackgroundColor(0xFFF4F6FA);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("L-DROID-G");
        title.setTextSize(30);
        title.setTextColor(0xFF102A43);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Instalador de aplicações para LG webOS");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFF52606D);
        subtitle.setPadding(0, 4, 0, 20);
        root.addView(subtitle);

        root.addView(label("Endereço IP da TV"));
        ip = field("Ex.: 192.168.1.50");
        root.addView(ip);
        root.addView(label("Porta SSH (padrão webOS: 9922)"));
        port = field("9922"); port.setText("9922"); root.addView(port);
        root.addView(label("Pacote .ipk — URL HTTPS"));
        packageUrl = field("https://servidor/aplicativo.ipk");
        root.addView(packageUrl);

        keyButton = button("1 · Importar chave privada SSH");
        root.addView(keyButton);
        keyButton.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_KEY);
        });

        testButton = button("2 · Testar conexão com a TV");
        root.addView(testButton);
        testButton.setOnClickListener(v -> runTask(() -> {
            Session s = connect();
            s.disconnect();
            return "Conexão SSH estabelecida. A chave foi aceita.";
        }));

        installButton = button("3 · Baixar e instalar pacote");
        root.addView(installButton);
        installButton.setOnClickListener(v -> runTask(() -> install()));

        status = new TextView(this);
        status.setText("Pronto. Smartphone e TV devem estar na mesma rede Wi-Fi.");
        status.setTextSize(14);
        status.setTextColor(0xFF243B53);
        status.setPadding(0, 22, 0, 0);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("\nRequisito: chave SSH válida da TV. No app Developer Mode da LG, ative o modo de desenvolvedor e o Key Server. A chave privada precisa ter sido obtida pelo procedimento oficial de configuração do webOS CLI. Não é a senha da conta LG.");
        note.setTextSize(12);
        note.setTextColor(0xFF52606D);
        note.setPadding(0, 16, 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private TextView label(String t) {
        TextView x = new TextView(this); x.setText(t); x.setTextSize(13);
        x.setTextColor(0xFF334E68); x.setPadding(0, 12, 0, 5); return x;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(15);
        e.setHint(hint); e.setPadding(12, 8, 12, 8);
        e.setBackgroundColor(0xFFFFFFFF); return e;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b;
    }
    private interface Task { String run() throws Exception; }
    private void runTask(Task task) {
        setBusy(true); status.setText("Processando…");
        new Thread(() -> {
            try {
                String result = task.run();
                runOnUiThread(() -> status.setText(result));
            } catch (Exception e) {
                String m = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> status.setText("Falha: " + m));
            } finally { runOnUiThread(() -> setBusy(false)); }
        }).start();
    }
    private void setBusy(boolean b) {
        keyButton.setEnabled(!b); testButton.setEnabled(!b); installButton.setEnabled(!b);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_KEY && resultCode == RESULT_OK && data != null) {
            keyUri = data.getData();
            getContentResolver().takePersistableUriPermission(keyUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            status.setText("Chave selecionada: " + keyUri.getLastPathSegment());
        }
    }

    private String getKeyText() throws Exception {
        if (keyUri == null) throw new Exception("Importe primeiro a chave privada SSH autorizada para esta TV.");
        try (InputStream in = getContentResolver().openInputStream(keyUri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }
    private Session connect() throws Exception {
        String host = ip.getText().toString().trim();
        if (host.isEmpty()) throw new Exception("Informe o endereço IP da TV.");
        int p;
        try { p = Integer.parseInt(port.getText().toString().trim()); }
        catch (Exception e) { throw new Exception("Porta inválida."); }
        JSch jsch = new JSch();
        byte[] key = getKeyText().getBytes(StandardCharsets.UTF_8);
        jsch.addIdentity("ldroidg-key", key, null, null);
        Session session = jsch.getSession("prisoner", host, p);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "publickey");
        session.setConfig(config);
        session.setTimeout(12000);
        session.connect(12000);
        return session;
    }
    private String exec(Session s, String command, int timeout) throws Exception {
        ChannelExec ch = (ChannelExec)s.openChannel("exec");
        ch.setCommand(command);
        ch.setInputStream(null);
        ByteArrayOutputStream stdout = new ByteArrayOutputStream();
        ByteArrayOutputStream stderr = new ByteArrayOutputStream();
        ch.setOutputStream(stdout); ch.setErrStream(stderr); ch.connect(10000);
        long end = System.currentTimeMillis() + timeout;
        while (!ch.isClosed() && System.currentTimeMillis() < end) Thread.sleep(200);
        if (!ch.isClosed()) { ch.disconnect(); throw new Exception("Tempo esgotado ao executar comando remoto."); }
        int code = ch.getExitStatus();
        String out = stdout.toString("UTF-8");
        String err = stderr.toString("UTF-8");
        ch.disconnect();
        if (code != 0) throw new Exception("Comando remoto falhou (" + code + "): " + err + " " + out);
        return out + err;
    }
    private String install() throws Exception {
        String url = packageUrl.getText().toString().trim();
        if (!url.startsWith("https://")) throw new Exception("Por segurança, use uma URL HTTPS para o pacote .ipk.");
        File local = new File(getCacheDir(), "package.ipk");
        URL u = new URL(url);
        HttpURLConnection c = (HttpURLConnection)u.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setInstanceFollowRedirects(true);
        c.connect();
        if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) throw new Exception("Download HTTP: " + c.getResponseCode());
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(local)) {
            byte[] buf = new byte[65536]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 500L * 1024 * 1024) throw new Exception("Pacote excede o limite de 500 MB.");
                out.write(buf, 0, n);
            }
        } finally { c.disconnect(); }
        if (local.length() < 64) throw new Exception("O arquivo baixado é muito pequeno para ser um pacote válido.");
        Session s = connect();
        try {
            String remote = "/media/developer/temp/ldroidg-package.ipk";
            exec(s, "mkdir -p /media/developer/temp", 10000);
            ChannelSftp ch = (ChannelSftp)s.openChannel("sftp");
            ch.connect(10000);
            try (InputStream in = new FileInputStream(local)) { ch.put(in, remote); }
            ch.disconnect();
            String payload = "{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\"" + remote + "\",\"subscribe\":true}";
            String cmd = "/usr/bin/luna-send-pub -n 60 -w 90000 'luna://com.webos.appInstallService/dev/install' '" + payload + "'";
            String output = exec(s, cmd, 100000);
            try { exec(s, "rm -f " + remote, 10000); } catch (Exception ignored) {}
            if (!output.contains("\"state\":\"installed\"") && !output.contains("\"returnValue\":true")) {
                throw new Exception("O comando foi enviado, mas não foi possível confirmar a instalação. Resposta: " + output);
            }
            return "Solicitação de instalação concluída. Resposta da TV:\n" + output;
        } finally { s.disconnect(); }
    }
}
